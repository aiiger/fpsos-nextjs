import { AnimatedBackground } from './components/AnimatedBackground';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { PricingSection } from './components/PricingSection';
import { FeaturesSection } from './components/FeaturesSection';
import { Footer } from './components/Footer';

function App() {
  return (
    <div className="relative min-h-screen bg-[#050505] overflow-x-hidden">
      <AnimatedBackground />
      <Navbar />
      <Hero />
      <FeaturesSection />
      <PricingSection />
      <Footer />
    </div>
  );
}

export default App;
