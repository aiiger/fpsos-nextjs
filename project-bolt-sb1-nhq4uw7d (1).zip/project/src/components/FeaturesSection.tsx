import { motion } from 'framer-motion';
import { Cpu, Zap, Shield, Gauge, Database, Lock } from 'lucide-react';

const features = [
  {
    icon: Cpu,
    title: 'CPU Optimization',
    description: 'Advanced processor tuning and core prioritization for maximum throughput.',
  },
  {
    icon: Gauge,
    title: 'Real-Time Monitoring',
    description: 'Live performance metrics and thermal monitoring during optimization.',
  },
  {
    icon: Zap,
    title: 'Power Efficiency',
    description: 'Reduce power consumption while maintaining peak performance.',
  },
  {
    icon: Database,
    title: 'Storage Optimization',
    description: 'Defragmentation and file system optimization for faster I/O.',
  },
  {
    icon: Shield,
    title: 'Security Hardening',
    description: 'Advanced security configurations and threat mitigation.',
  },
  {
    icon: Lock,
    title: 'Data Protection',
    description: 'Comprehensive backup and recovery solutions included.',
  },
];

export function FeaturesSection() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <section id="features" className="relative py-32 px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-5xl md:text-6xl font-900 text-white tracking-tight mb-4">
            Enterprise-Grade
            <br />
            <span className="bg-gradient-to-r from-orange-400 via-orange-500 to-red-600 bg-clip-text text-transparent">
              Optimization Features
            </span>
          </h2>
          <p className="text-lg text-neutral-400 max-w-2xl mx-auto">
            Military-precision tools for maximum system performance and reliability.
          </p>
        </motion.div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={index}
                className="group relative"
                variants={itemVariants}
              >
                <div className="absolute inset-0 rounded-xl bg-gradient-to-b from-orange-500/10 to-red-900/10 opacity-0 group-hover:opacity-100 blur-xl transition-opacity duration-500" />

                <div className="relative rounded-xl border border-neutral-800/50 bg-neutral-900/40 backdrop-blur-xl p-8 hover:border-orange-500/50 transition-colors duration-300">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="rounded-lg bg-orange-500/10 p-3">
                      <Icon className="w-6 h-6 text-orange-500" />
                    </div>
                  </div>

                  <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
                  <p className="text-neutral-400 text-sm leading-relaxed">{feature.description}</p>

                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-orange-500/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
