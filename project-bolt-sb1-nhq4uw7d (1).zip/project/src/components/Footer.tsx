import { motion } from 'framer-motion';
import { Cpu, Github, Twitter, Linkedin, Mail } from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();

  const links = {
    product: [
      { label: 'Features', href: '#' },
      { label: 'Pricing', href: '#' },
      { label: 'Security', href: '#' },
      { label: 'Support', href: '#' },
    ],
    company: [
      { label: 'About', href: '#' },
      { label: 'Blog', href: '#' },
      { label: 'Careers', href: '#' },
      { label: 'Contact', href: '#' },
    ],
    legal: [
      { label: 'Privacy', href: '#' },
      { label: 'Terms', href: '#' },
      { label: 'Cookies', href: '#' },
    ],
  };

  const socials = [
    { icon: Github, href: '#', label: 'GitHub' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
    { icon: Mail, href: '#', label: 'Email' },
  ];

  return (
    <footer className="relative border-t border-neutral-800/50 bg-neutral-900/30">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-12 mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <div className="flex items-center gap-2 mb-4">
              <Cpu className="w-6 h-6 text-orange-500" />
              <span className="text-lg font-bold text-white tracking-tight">FPSOS</span>
            </div>
            <p className="text-sm text-neutral-400">
              Military-grade PC optimization for maximum performance and stability.
            </p>

            <div className="flex items-center gap-3 mt-6">
              {socials.map((social, index) => {
                const Icon = social.icon;
                return (
                  <motion.a
                    key={index}
                    href={social.href}
                    aria-label={social.label}
                    className="rounded-lg bg-neutral-800/50 p-2.5 text-neutral-400 hover:bg-orange-500/20 hover:text-orange-500 transition-all duration-300"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Icon className="w-4 h-4" />
                  </motion.a>
                );
              })}
            </div>
          </motion.div>

          {Object.entries(links).map(([category, items]) => (
            <motion.div
              key={category}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
            >
              <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4 capitalize">
                {category}
              </h4>
              <ul className="space-y-3">
                {items.map((item, index) => (
                  <li key={index}>
                    <a
                      href={item.href}
                      className="text-sm text-neutral-400 hover:text-white transition-colors duration-200"
                    >
                      {item.label}
                    </a>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        <div className="h-px bg-gradient-to-r from-transparent via-neutral-700 to-transparent mb-8" />

        <motion.div
          className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-neutral-400"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          viewport={{ once: true }}
        >
          <p>&copy; {currentYear} FPSOS. All rights reserved. | Military-Grade PC Optimization</p>
          <div className="flex items-center gap-6">
            <a href="#" className="hover:text-white transition-colors duration-200">
              Status
            </a>
            <a href="#" className="hover:text-white transition-colors duration-200">
              Documentation
            </a>
          </div>
        </motion.div>
      </div>

      <div className="absolute top-0 left-1/4 w-[300px] h-[300px] bg-orange-500/5 rounded-full blur-3xl pointer-events-none" />
    </footer>
  );
}
