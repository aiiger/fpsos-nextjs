import { motion } from 'framer-motion';
import { Cpu, Zap, TrendingUp, Shield } from 'lucide-react';

export function Hero() {
  const stats = [
    { label: 'Systems Optimized', value: '2,500+', icon: Cpu },
    { label: 'Avg Performance Gain', value: '+42%', icon: TrendingUp },
    { label: 'Customer Satisfaction', value: '98%', icon: Shield },
    { label: 'Response Time', value: '<24h', icon: Zap },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-6 pt-32">
      <motion.div
        className="text-center max-w-5xl mx-auto space-y-8"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div
          className="inline-flex items-center gap-3 px-5 py-2 rounded-full bg-neutral-900/50 border border-neutral-800/50 backdrop-blur-sm"
          variants={itemVariants}
        >
          <Cpu className="w-4 h-4 text-orange-500" />
          <span className="text-sm text-neutral-300 font-medium tracking-wide">MILITARY-GRADE PRECISION</span>
        </motion.div>

        <motion.h1
          className="text-6xl md:text-7xl lg:text-8xl font-900 text-white tracking-tighter leading-tight"
          variants={itemVariants}
        >
          Choose Your
          <br />
          <span className="bg-gradient-to-r from-orange-400 via-orange-500 to-red-600 bg-clip-text text-transparent inline-block">
            Optimization Tier
          </span>
        </motion.h1>

        <motion.p
          className="text-lg md:text-xl text-neutral-400 max-w-2xl mx-auto leading-relaxed"
          variants={itemVariants}
        >
          High-performance PC optimization engineered for precision. From stability fixes to extreme BIOS tuning.
        </motion.p>

        <motion.div
          className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-8"
          variants={containerVariants}
        >
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={index}
                className="rounded-xl bg-neutral-900/40 border border-neutral-800/30 backdrop-blur-sm p-4 hover:bg-neutral-900/60 transition-all duration-300"
                variants={itemVariants}
              >
                <Icon className="w-5 h-5 text-orange-500 mb-3" />
                <div className="text-2xl md:text-3xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-xs md:text-sm text-neutral-400">{stat.label}</div>
              </motion.div>
            );
          })}
        </motion.div>
      </motion.div>
    </section>
  );
}
