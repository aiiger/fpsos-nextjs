import { motion } from 'framer-motion';
import { Cpu, Menu, X } from 'lucide-react';
import { useState } from 'react';

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { label: 'Services', href: '#services' },
    { label: 'Packages', href: '#pricing' },
    { label: 'Features', href: '#features' },
    { label: 'About', href: '#about' },
  ];

  return (
    <motion.nav
      className="fixed top-0 left-0 right-0 z-50 px-6 py-6"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between px-6 py-4 rounded-2xl bg-neutral-900/40 backdrop-blur-xl border border-neutral-800/30 hover:border-neutral-700/50 transition-colors duration-300">
          <motion.div
            className="flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
            transition={{ type: 'spring', stiffness: 400, damping: 10 }}
          >
            <Cpu className="w-6 h-6 text-orange-500" />
            <span className="text-xl font-bold text-white tracking-tight">FPSOS</span>
          </motion.div>

          <div className="hidden md:flex items-center gap-12">
            {navLinks.map((link, index) => (
              <motion.a
                key={index}
                href={link.href}
                className="text-sm text-neutral-300 hover:text-white font-medium transition-colors relative group"
                whileHover={{ scale: 1.05 }}
              >
                {link.label}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-orange-500 to-red-600 group-hover:w-full transition-all duration-300" />
              </motion.a>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-4">
            <motion.a
              href="#discord"
              className="px-4 py-2 text-sm text-neutral-300 hover:text-white font-medium transition-colors"
              whileHover={{ scale: 1.05 }}
            >
              Discord
            </motion.a>
            <motion.button
              className="px-6 py-2.5 rounded-lg bg-gradient-to-r from-orange-500 to-red-600 text-white text-sm font-bold tracking-tight"
              whileHover={{ scale: 1.05, boxShadow: '0 10px 30px rgba(249, 115, 22, 0.3)' }}
              whileTap={{ scale: 0.95 }}
            >
              Get Started
            </motion.button>
          </div>

          <motion.button
            className="md:hidden p-2 rounded-lg hover:bg-neutral-800/50 transition-colors"
            onClick={() => setIsOpen(!isOpen)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {isOpen ? (
              <X className="w-6 h-6 text-white" />
            ) : (
              <Menu className="w-6 h-6 text-white" />
            )}
          </motion.button>
        </div>

        {isOpen && (
          <motion.div
            className="md:hidden mt-4 rounded-2xl bg-neutral-900/40 backdrop-blur-xl border border-neutral-800/30 p-6 space-y-4"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            {navLinks.map((link, index) => (
              <a
                key={index}
                href={link.href}
                className="block text-sm text-neutral-300 hover:text-white font-medium transition-colors py-2"
                onClick={() => setIsOpen(false)}
              >
                {link.label}
              </a>
            ))}
            <div className="h-px bg-neutral-700/50 my-4" />
            <motion.button
              className="w-full px-6 py-3 rounded-lg bg-gradient-to-r from-orange-500 to-red-600 text-white text-sm font-bold tracking-tight"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              Get Started
            </motion.button>
          </motion.div>
        )}
      </div>
    </motion.nav>
  );
}
