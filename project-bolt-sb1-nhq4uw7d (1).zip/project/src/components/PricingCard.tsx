import { motion } from 'framer-motion';
import { Check, Zap } from 'lucide-react';
import { useState, useRef, MouseEvent } from 'react';

interface PricingCardProps {
  title: string;
  price: number;
  description: string;
  features: string[];
  highlighted?: boolean;
}

export function PricingCard({ title, price, description, features, highlighted = false }: PricingCardProps) {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;

    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setMousePosition({ x, y });
  };

  const accentColor = highlighted ? 'cyan' : 'orange';
  const accentClass = highlighted ? 'text-cyan-500' : 'text-orange-500';
  const borderColor = highlighted
    ? 'rgba(34, 211, 238, 0.5)'
    : isHovered ? 'rgba(249, 115, 22, 0.5)' : 'rgba(64, 64, 64, 0.3)';

  return (
    <motion.div
      ref={cardRef}
      className="relative group"
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true }}
    >
      {highlighted && (
        <motion.div
          className="absolute -inset-1 rounded-2xl bg-gradient-to-b from-cyan-500/30 to-blue-900/20 blur-xl"
          animate={{ opacity: [0.5, 0.8, 0.5] }}
          transition={{ duration: 3, repeat: Infinity }}
        />
      )}

      <div className="absolute inset-0 rounded-2xl bg-gradient-to-b from-orange-500/20 to-red-900/20 opacity-0 group-hover:opacity-100 blur-xl transition-opacity duration-500" />

      <div
        className="relative overflow-hidden rounded-2xl backdrop-blur-xl border transition-all duration-300"
        style={{
          background: highlighted
            ? 'rgba(23, 23, 23, 0.7)'
            : 'rgba(23, 23, 23, 0.6)',
          borderColor,
          borderWidth: '1px',
        }}
      >
        {isHovered && (
          <div
            className="absolute pointer-events-none transition-opacity duration-300"
            style={{
              width: '400px',
              height: '400px',
              left: mousePosition.x - 200,
              top: mousePosition.y - 200,
              background: accentColor === 'cyan'
                ? 'radial-gradient(circle, rgba(34, 211, 238, 0.15) 0%, rgba(34, 211, 238, 0.08) 30%, transparent 60%)'
                : 'radial-gradient(circle, rgba(251, 146, 60, 0.15) 0%, rgba(249, 115, 22, 0.08) 30%, transparent 60%)',
            }}
          />
        )}

        <div className="absolute inset-0 opacity-[0.015]" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='3.5' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
        }} />

        <div className="relative p-8 z-10">
          {highlighted && (
            <motion.div
              className="absolute -top-4 left-1/2 -translate-x-1/2"
              animate={{ y: [0, -2, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <span className="px-4 py-1.5 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs font-bold tracking-widest rounded-full flex items-center gap-2">
                <Zap className="w-3 h-3" />
                BEST VALUE
              </span>
            </motion.div>
          )}

          <div className="space-y-6">
            <div>
              <h3 className="text-3xl font-900 text-white tracking-tight mb-2">{title}</h3>
              <p className={`text-sm font-medium ${accentClass}`}>{description}</p>
            </div>

            <div className="flex items-baseline gap-2">
              <span className="text-6xl font-900 text-white tracking-tight">AED {price}</span>
              <span className="text-neutral-400 text-sm">/service</span>
            </div>

            <div className="h-px bg-gradient-to-r from-transparent via-neutral-700 to-transparent" />

            <ul className="space-y-3">
              {features.map((feature, index) => (
                <motion.li
                  key={index}
                  className="flex items-start gap-3"
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  viewport={{ once: true }}
                >
                  <div className={`mt-0.5 rounded-full ${accentClass === 'text-cyan-500' ? 'bg-cyan-500/10' : 'bg-orange-500/10'} p-1 flex-shrink-0`}>
                    <Check className={`w-4 h-4 ${accentClass}`} />
                  </div>
                  <span className="text-neutral-300 text-sm leading-relaxed">{feature}</span>
                </motion.li>
              ))}
            </ul>

            <motion.button
              className="w-full py-4 rounded-xl font-bold tracking-tight transition-all duration-300 mt-8"
              style={{
                background: highlighted
                  ? 'linear-gradient(135deg, rgba(34, 211, 238, 1) 0%, rgba(6, 182, 212, 1) 100%)'
                  : 'rgba(38, 38, 38, 0.8)',
                color: highlighted ? '#000' : 'rgba(245, 245, 245, 0.9)',
                border: highlighted ? 'none' : '1px solid rgba(64, 64, 64, 0.5)',
              }}
              whileHover={{
                scale: 1.02,
                boxShadow: highlighted
                  ? '0 20px 40px rgba(34, 211, 238, 0.3)'
                  : '0 10px 30px rgba(0, 0, 0, 0.5)'
              }}
              whileTap={{ scale: 0.98 }}
            >
              Select {title}
            </motion.button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
