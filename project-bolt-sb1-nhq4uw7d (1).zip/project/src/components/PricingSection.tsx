import { motion } from 'framer-motion';
import { PricingCard } from './PricingCard';

const pricingTiers = [
  {
    title: 'Starter',
    price: 199,
    description: 'Quick Remote Fix',
    features: [
      'Stability triage and diagnostics',
      'Remote desktop optimization',
      'Critical error resolution',
      'Basic performance tuning',
      '48-hour turnaround',
    ],
  },
  {
    title: 'Professional',
    price: 399,
    description: 'Full System Tune-Up',
    features: [
      'Complete Windows optimization',
      'Advanced BIOS configuration',
      'Network stack optimization',
      'Storage and memory tuning',
      'Startup and service optimization',
      'Priority 24-hour support',
    ],
    highlighted: true,
  },
  {
    title: 'Elite',
    price: 699,
    description: 'Extreme BIOSPRIME',
    features: [
      'Manual RAM timing calibration',
      'Precision voltage sculpting',
      'Custom power delivery tuning',
      'Advanced thermal optimization',
      'Stability stress testing suite',
      'Dedicated engineer support',
      'Lifetime optimization warranty',
    ],
  },
];

export function PricingSection() {
  return (
    <section id="pricing" className="relative py-32 px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-5xl md:text-6xl font-900 text-white tracking-tight mb-4">
            Choose Your
            <br />
            <span className="bg-gradient-to-r from-orange-400 via-orange-500 to-red-600 bg-clip-text text-transparent">
              Optimization Tier
            </span>
          </h2>
          <p className="text-lg text-neutral-400 max-w-2xl mx-auto">
            Transparent pricing for every optimization level. Choose the perfect tier for your needs.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {pricingTiers.map((tier, index) => (
            <PricingCard
              key={index}
              title={tier.title}
              price={tier.price}
              description={tier.description}
              features={tier.features}
              highlighted={tier.highlighted}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
